﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Sessia1
{
   
    public partial class Form5 : Form
    {
        string conn_string = @"Data Source=DESKTOP-J3F0GHQ\SQLEXPRESS;Initial Catalog=sesia1;Integrated Security=True";
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "sesia1DataSet.Tovar". При необходимости она может быть перемещена или удалена.
            this.tovarTableAdapter.Fill(this.sesia1DataSet.Tovar);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f4 = new Form3();
            f4.ShowDialog();
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            {
                SqlConnection sql_conn = new SqlConnection(conn_string);
                string sqlquery = "select * from [dbo].[Tovar] where Наименование Like '" + textBox1.Text + "%'";
                sql_conn.Open(); // открыть соединение
                SqlCommand sqlcomm = new SqlCommand(sqlquery, sql_conn);
                SqlDataAdapter sdr = new SqlDataAdapter(sqlcomm);
                DataTable dt = new DataTable();
                sdr.Fill(dt);
                dataGridView1.DataSource = dt;
                sql_conn.Close();
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            SqlConnection sql_conn = new SqlConnection(conn_string);
            string sqlquery = "select * from [dbo].[Tovar] where Стоимость Like '" + textBox2.Text + "%'";
            sql_conn.Open(); // открыть соединение
            SqlCommand sqlcomm = new SqlCommand(sqlquery, sql_conn);
            SqlDataAdapter sdl = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sdl.Fill(dt);
            dataGridView1.DataSource = dt;
            sql_conn.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            SqlConnection sql_conn = new SqlConnection(conn_string);
            string sqlquery = "select * from [dbo].[Tovar] ";
            sql_conn.Open(); // открыть соединение
            SqlCommand sqlcomm = new SqlCommand(sqlquery, sql_conn);
            SqlDataAdapter sdl = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sdl.Fill(dt);
            dataGridView1.DataSource = dt;
            sql_conn.Close();
        }
    }
}
